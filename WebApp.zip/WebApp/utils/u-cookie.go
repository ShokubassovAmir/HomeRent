package utils

import (
	"net/http"

	uuid "github.com/satori/go.uuid"
)

// NewCookie ..
func NewCookie(name string) *http.Cookie {
	sID := uuid.NewV4()
	c := &http.Cookie{
		Name:   name,
		Value:  sID.String(),
		MaxAge: 5,
	}
	return c
}
