package utils

import (
	"html/template"
	"net/http"

	"github.com/Nurshat0092/homeRent/controller"
)

var tpl *template.Template
var fm = template.FuncMap{
	"tf": controller.TimeFormat,
}

// LoadTemplates ..
func init() {
	tpl = template.Must(template.New("").Funcs(fm).ParseGlob("templates/*.html"))
}

// ExecuteTemplate ..
func ExecuteTemplate(w http.ResponseWriter, template string, data interface{}) {
	tpl.ExecuteTemplate(w, template, data)
}
