package middleware

import (
	"database/sql"
	"net/http"
	"time"

	"github.com/Nurshat0092/homeRent/database"
)

var timer = time.NewTimer(time.Second * 30 * 60)

// AuthRequired ..
func AuthRequired(handler http.HandlerFunc) http.HandlerFunc {
	return func(w http.ResponseWriter, r *http.Request) {
		c, err := r.Cookie("session")
		if err != nil {
			http.Redirect(w, r, "/admin-login", http.StatusSeeOther)
			return
		}
		c.MaxAge = 30 * 60
		http.SetCookie(w, c)
		timer.Stop()
		timer = time.AfterFunc(30*60*time.Second, func() {
			database.DeleteSession(c.Value)
		})
		if _, err := database.SelectSessionByID(c.Value); err == sql.ErrNoRows {
			http.Redirect(w, r, "/admin-login", http.StatusSeeOther)
			return
		}
		handler.ServeHTTP(w, r)
	}
}

// UserAvoided ..
func UserAvoided(handler http.HandlerFunc) http.HandlerFunc {
	return func(w http.ResponseWriter, r *http.Request) {
		c, err := r.Cookie("session")
		if err == nil {
			if _, err = database.SelectSessionByID(c.Value); err != sql.ErrNoRows {
				http.Redirect(w, r, "/admin", http.StatusSeeOther)
				return
			}
		}
		handler.ServeHTTP(w, r)
	}
}
