package controller

import (
	"fmt"
	"net/smtp"

	"github.com/Nurshat0092/homeRent/models"
)

type smtpServer struct {
	host string
	port string
}

// Address URI to smtp server
func (s *smtpServer) Address() string {
	return s.host + ":" + s.port
}

// Email ..
func Email(e models.Email) {
	// Sender data.
	from := "david.lennon.2020@gmail.com"
	password := "lennontralala1"
	// Receiver email address.
	// to := []string{
	// 	"160107101@stu.sdu.edu.kz",
	// 	// "secondemail@gmail.com",
	// }
	// smtp server configuration.
	smtpServer := smtpServer{host: "smtp.gmail.com", port: "587"}
	// Message.
	// message := []byte("This is a really unimaginative message, I know.")
	// Authentication.
	auth := smtp.PlainAuth("", from, password, smtpServer.host)
	// Sending email.
	err := smtp.SendMail(smtpServer.Address(), auth, from, e.Addrs, e.Message)
	if err != nil {
		fmt.Println(err)
		return
	}
}
