package controller

import (
	"fmt"
	"net/smtp"

	"github.com/jordan-wright/email"
)

// SendEmail bla bla bla
func SendEmail(gmail, name, phone string, fileNames []string) error {

	e := email.NewEmail()
	e.From = "David Lennon <david.lennon.2020@gmail.com>"
	e.To = []string{"accnt5533@gmail.com"}
	e.Subject = "Awesome Subject!!!"

	for i := range fileNames {
		e.AttachFile("./tmp/" + fileNames[i])
	}
	e.Text = []byte(fmt.Sprintf(
		"Email: %s\n"+
			"Phone: %s\n"+
			"Name: %s\n", gmail, phone, name))
	err := e.Send("smtp.gmail.com:587", smtp.PlainAuth("", "david.lennon.2020@gmail.com", "lennontralala1", "smtp.gmail.com"))
	return err
}
