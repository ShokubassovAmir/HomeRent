package controller

import "time"

// TimeFormat ..
func TimeFormat(unixTime int64) string {
	return time.Unix(unixTime, 0).Format("2 Jan 2006 15:04")
}
