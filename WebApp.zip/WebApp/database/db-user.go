package database

import "github.com/Nurshat0092/homeRent/models"

// SelectUserByEmail ..
func SelectUserByEmail(email string) (models.User, error) {
	row := db.QueryRow("select id, email, username, password, phone, role from users where email = $1", email)
	user := models.User{}
	err := row.Scan(&user.ID, &user.Email, &user.Username, &user.Password, &user.Phone, &user.Role)
	return user, err
}
