package database

import (
	"database/sql"
	"log"

	_ "github.com/mattn/go-sqlite3"
)

var db *sql.DB
var offset = 0

func init() {
	var err error
	db, err = sql.Open("sqlite3", "./database/homerent.db")
	if err != nil {
		log.Fatalln("Database failed")
	}
}

// Close ..
func Close() {
	db.Close()
}

// CreateUser ..
// func CreateUser(u models.User) {
// 	// _, err := db.Exec("insert into users (username, email, password, phone, role) values ($1, $2, $3, $4, $5)", u.Username, u.Email, string(u.Password), u.Phone, u.Role)
// 	_, err := db.Exec("insert or replace into users (email, username, password, phone, role) values ((select email from users where email = $1), $2, $3, $4, $5);", u.Email, u.Username, string(u.Password), u.Phone, u.Role)
// 	fmt.Println(err)
// }
