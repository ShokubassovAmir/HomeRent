package database

import (
	"fmt"

	"github.com/Nurshat0092/homeRent/models"
)

// CreateQuestion ..
func CreateQuestion(q models.Question) {
	_, err := db.Exec(`insert into questions 
		(title, answer, email, username, phone, published, unixtime) values ($1, $2, $3, $4, $5, $6, $7)`,
		q.Title, q.Answer, q.Email, q.Username, q.Phone, q.Published, q.UnixTime)
	fmt.Println(err)
}

// UpdateQuestionAnswer ..
func UpdateQuestionAnswer(qID int, answer string) {
	db.Exec("update questions set answer = $1 where id = $2", answer, qID)
}

// SelectUnansweredQuestion ..
func SelectUnansweredQuestion(order int) (models.Question, error) {
	amount := CountUnansweredQuestions()
	if order == 1 {
		offset++
	} else if order == -1 {
		offset--
	}
	if offset < 0 {
		offset = amount - 1
	} else if offset >= amount || amount == 0 || order == 0 {
		offset = 0
	}
	row := db.QueryRow("select * from questions where answer = $1 limit 1 offset $2", "", offset)
	q := models.Question{}
	err := row.Scan(&q.ID, &q.Title, &q.Answer, &q.Email, &q.Username, &q.Phone, &q.Published, &q.UnixTime)
	fmt.Println(err)
	return q, err
}

// CountUnansweredQuestions ..
func CountUnansweredQuestions() int {
	row := db.QueryRow("select count(*) from questions where answer = $1", "")
	c := models.Counter{}
	err := row.Scan(&c.Amount)
	if err != nil {
		fmt.Println(err, "Count Questions database/database.go")
	}
	return c.Amount
}
