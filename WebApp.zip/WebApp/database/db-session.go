package database

import (
	"database/sql"
	"fmt"

	"github.com/Nurshat0092/homeRent/models"
)

// SelectSessionByID ..
func SelectSessionByID(sessionID string) (models.Session, error) {
	row := db.QueryRow("select * from sessions where sessionID = $1", sessionID)
	session := models.Session{}
	err := row.Scan(&session.SessionID, &session.Email)
	return session, err
}

// SelectActiveUser ..
func SelectActiveUser(email string) bool {
	row := db.QueryRow("select * from sessions where email = $1", email)
	s := models.Session{}
	err := row.Scan(&s.SessionID, &s.Email)
	fmt.Println(s, err)
	if err == sql.ErrNoRows {
		return false
	}
	return true
}

// CreateSession ..
func CreateSession(s models.Session) {
	_, err := db.Exec("insert into sessions (sessionID, email) values ($1, $2)", s.SessionID, s.Email)
	fmt.Println(err)
}

// DeleteSession ..
func DeleteSession(sessionID string) {
	_, err := db.Exec("delete from sessions where sessionID = $1", sessionID)
	fmt.Println(err)
}
