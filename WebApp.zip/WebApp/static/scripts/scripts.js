$(function () {
    $('.hamburger-menu').on('click', function () {
        console.log("there")
        $('.toggle').toggleClass('open');
        $('.nav-list').toggleClass('open');
    });
    $('.nav-link').on('click', function () {
        console.log("here")
        $('.toggle').toggleClass('open');
        $('.nav-list').toggleClass('open');
    });
    $('.nav-link').on('click', function () {
        console.log("here")
        $('.toggle').toggleClass('open');
        $('.nav-list').toggleClass('open');
    });
    AOS.init({
        easing: 'ease',
        duration: 1000,
    });
});

const btns = document.querySelectorAll(".question-btn");

btns.forEach(function(btn) {
    btn.addEventListener("click", function(e) {
        const question = e.currentTarget.parentElement.parentElement;
        question.classList.toggle("show-text");
        console.log(e.currentTarget);
    });
});