package httprouter

import (
	"net/http"

	"github.com/Nurshat0092/homeRent/database"
)

func logoutHandler(w http.ResponseWriter, r *http.Request) {
	switch r.Method {
	case http.MethodGet:
		http.Redirect(w, r, "/admin", http.StatusSeeOther)
	case http.MethodPost:
		c, _ := r.Cookie("session")
		database.DeleteSession(c.Value)
		c.MaxAge = -1
		http.SetCookie(w, c)
		http.Redirect(w, r, "/admin-login", http.StatusSeeOther)
	case http.MethodPut:

	case http.MethodDelete:

	}
}
