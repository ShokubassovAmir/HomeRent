package httprouter

import (
	"net/http"

	"github.com/Nurshat0092/homeRent/utils"
)

func indexHandler(w http.ResponseWriter, r *http.Request) {
	switch r.Method {
	case http.MethodGet:
		utils.ExecuteTemplate(w, "index.html", nil)
	case http.MethodPost:

	case http.MethodPut:

	case http.MethodDelete:

	}
}
