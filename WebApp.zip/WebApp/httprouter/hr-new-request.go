package httprouter

import (
	"fmt"
	"io"
	"log"
	"net/http"
	"os"

	"github.com/Nurshat0092/homeRent/controller"
	"github.com/Nurshat0092/homeRent/utils"
)

func newRequestHandler(w http.ResponseWriter, r *http.Request) {
	switch r.Method {
	case http.MethodGet:
		utils.ExecuteTemplate(w, "newrequest.html", nil)
	case http.MethodPost:
		err := r.ParseMultipartForm(200000) // grab the multipart form
		if err != nil {
			fmt.Fprintln(w, err)
			return
		}

		formdata := r.MultipartForm // ok, no problem so far, read the Form data

		//get the *fileheaders
		files := formdata.File["multiplefiles"] // grab the filenames
		fileNames := []string{}
		for i := range files { // loop through the files one by one
			file, err := files[i].Open()
			defer file.Close()
			if err != nil {
				fmt.Fprintln(w, err)
				return
			}

			out, err := os.Create("./tmp/" + files[i].Filename)

			defer out.Close()
			if err != nil {
				fmt.Fprintf(w, "Unable to create the file for writing. Check your write access privilege")
				return
			}

			_, err = io.Copy(out, file) // file not files[i] !

			if err != nil {
				fmt.Fprintln(w, err)
				return
			}
			fileNames = append(fileNames, files[i].Filename)

		}
		err = controller.SendEmail(r.FormValue("email"), r.FormValue("username"), r.FormValue("phone"), fileNames)
		if err != nil {
			log.Fatalln(err)
		}
		smth := "smth"
		utils.ExecuteTemplate(w, "newrequest.html", smth)
	case http.MethodPut:

	case http.MethodDelete:

	}
}
