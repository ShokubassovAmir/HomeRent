package httprouter

import (
	"net/http"

	"github.com/Nurshat0092/homeRent/middleware"
)

// NewRouter ..
func NewRouter() (mux *http.ServeMux) {
	mux = &http.ServeMux{}

	mux.HandleFunc("/faq", faqHandler)
	mux.HandleFunc("/admin-login", middleware.UserAvoided(loginHandler))
	mux.HandleFunc("/admin", middleware.AuthRequired(adminHandler))
	mux.HandleFunc("/newquestion", newQuestionHandler)
	mux.HandleFunc("/newrequest", newRequestHandler)
	mux.HandleFunc("/logout", middleware.AuthRequired(logoutHandler))
	mux.HandleFunc("/", indexHandler)

	fs := http.FileServer(http.Dir("./static/"))
	mux.Handle("/static/", http.StripPrefix("/static/", fs))

	return
}
