package httprouter

import (
	"database/sql"
	"fmt"
	"net/http"

	"github.com/Nurshat0092/homeRent/database"
	"github.com/Nurshat0092/homeRent/models"
	"github.com/Nurshat0092/homeRent/utils"
	"golang.org/x/crypto/bcrypt"
)

func loginHandler(w http.ResponseWriter, r *http.Request) {
	switch r.Method {
	case http.MethodGet:
		utils.ExecuteTemplate(w, "login.html", nil)
	case http.MethodPost:
		email := r.FormValue("email")
		passw := r.FormValue("password")

		u, err := database.SelectUserByEmail(email)
		if err == sql.ErrNoRows {
			fmt.Println("no such email registered")
			http.Redirect(w, r, "/admin-login", http.StatusSeeOther)
			return
		} else if err != nil {
			fmt.Println("Internal Server Error")
			return
		}
		if u.Role != "admin" {
			fmt.Println("You don't possess admin priviligies")
			return
		}
		if err = bcrypt.CompareHashAndPassword(u.Password, []byte(passw)); err != nil {
			fmt.Println("Parol is wrong")
			http.Redirect(w, r, "/admin-login", http.StatusSeeOther)
			return
		}
		if database.SelectActiveUser(email) {
			fmt.Println("User is already active")
			http.Redirect(w, r, "admin-login", http.StatusSeeOther)
			return
		}
		c := utils.NewCookie("session")
		http.SetCookie(w, c)
		session := models.Session{SessionID: c.Value, Email: email}
		database.CreateSession(session)
		http.Redirect(w, r, "/admin", http.StatusSeeOther)
	case http.MethodPut:

	case http.MethodDelete:

	}
}
