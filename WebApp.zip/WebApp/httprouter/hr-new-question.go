package httprouter

import (
	"net/http"
	"time"

	"github.com/Nurshat0092/homeRent/database"
	"github.com/Nurshat0092/homeRent/models"
	"github.com/Nurshat0092/homeRent/utils"
)

func newQuestionHandler(w http.ResponseWriter, r *http.Request) {
	switch r.Method {
	case http.MethodGet:
		utils.ExecuteTemplate(w, "newquestion.html", nil)
	case http.MethodPost:
		email := r.FormValue("email")
		phone := r.FormValue("phone")
		usern := r.FormValue("username")
		title := r.FormValue("title")
		// u := models.User{Email: email, Username: usern, Phone: phone, Role: "user"}
		// database.CreateUser(u)
		q := models.Question{Title: title, Answer: "", Email: email, Username: usern, Phone: phone, Published: "no", UnixTime: time.Now().Unix()}
		database.CreateQuestion(q)
		w.WriteHeader(http.StatusOK)
		utils.ExecuteTemplate(w, "newquestion.html", "created")
	case http.MethodPut:

	case http.MethodDelete:

	}
}
