package httprouter

import (
	"fmt"
	"net/http"

	"github.com/Nurshat0092/homeRent/controller"
	"github.com/Nurshat0092/homeRent/database"
	"github.com/Nurshat0092/homeRent/models"
	"github.com/Nurshat0092/homeRent/utils"
)

func adminHandler(w http.ResponseWriter, r *http.Request) {
	c, _ := r.Cookie("session")
	s, _ := database.SelectSessionByID(c.Value)
	u, _ := database.SelectUserByEmail(s.Email)
	p := models.PageData{PageTitle: "admin page", User: u, Data: nil}
	switch r.Method {
	case http.MethodGet:
		val := r.FormValue("button")
		offset := 0
		if val == "Предыдущий" {
			offset = 1
		} else if val == "Следующий" {
			offset = -1
		} else {
			offset = 0
		}
		q, err := database.SelectUnansweredQuestion(offset)
		if err != nil {
			// http.Error(w, "Database has no questions", http.StatusOK)
			// return
			fmt.Println(w, "Database have no questions")
		}
		p.Data = q
		utils.ExecuteTemplate(w, "admin.html", p)
	case http.MethodPost:
		val := r.FormValue("input")
		msg := r.FormValue("message")
		email := r.FormValue("email")
		fmt.Println(msg)
		if val == "Ответить" {
			e := models.Email{Addrs: []string{email}, Message: []byte(msg)}
			controller.Email(e)
			http.Redirect(w, r, "/admin", http.StatusSeeOther)
		} else if val == "Опубликовать" {

		}
	case http.MethodPut:

	case http.MethodDelete:

	}
}
