package models

// Counter ..
type Counter struct {
	Amount int
}