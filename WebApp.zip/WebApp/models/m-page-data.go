package models

// PageData ..
type PageData struct {
	PageTitle string
	User      User
	Data      interface{}
}
