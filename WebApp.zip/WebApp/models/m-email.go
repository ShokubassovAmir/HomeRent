package models

// Email ..
type Email struct {
	Addrs   []string
	Message []byte
}
