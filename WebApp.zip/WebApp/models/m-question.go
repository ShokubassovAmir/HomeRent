package models

// Question ..
type Question struct {
	ID        int
	Title     string
	Answer    string
	Email     string
	Username  string
	Phone     string
	Published string
	UnixTime  int64
}
