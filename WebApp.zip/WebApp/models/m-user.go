package models

// User ..
type User struct {
	ID       int
	Email    string
	Username string
	Password []byte
	Phone    string
	Role     string
}
