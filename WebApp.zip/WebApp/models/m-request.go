package models

// Request ..
type Request struct {
	Addrs       []string
	Subject     string
	AttachFiles []string
	Text        []byte
}
