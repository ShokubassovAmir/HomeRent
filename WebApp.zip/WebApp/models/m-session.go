package models

type Session struct {
	SessionID string
	Email     string
}
