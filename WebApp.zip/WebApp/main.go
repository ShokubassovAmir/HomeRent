package main

import (
	"fmt"
	"log"
	"net/http"

	"github.com/Nurshat0092/homeRent/database"
	"github.com/Nurshat0092/homeRent/httprouter"
)

func main() {
	defer database.Close()
	fmt.Println("Server is listenning...")
	mux := httprouter.NewRouter()
	if err := http.ListenAndServe(":8080", mux); err != nil {
		log.Fatalln(err.Error())
	}
}
